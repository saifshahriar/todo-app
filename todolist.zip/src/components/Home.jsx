function Home() {
    return <div>
        <center>
            Welcome to our Todo App! 🚀
        </center>
    </div>
}

export { Home }